package laboration0_system;

public interface Action {
	public String getActionTitle();
	public void action(Controller controller);
}
