package laboration0_system;

public interface BitConverter {
	public boolean[] intToArray(int state);
	public int arrayToInt(boolean[] switchState);
}
