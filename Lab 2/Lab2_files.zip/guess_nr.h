/*
 * guess_nr.h
 *
 * Created: 2015-11-27 16:28:36
 *  Author: staff
 */ 
#ifndef GUESS_NR_H_
#define GUESS_NR_H_

#include <inttypes.h>
void play_guess_nr(uint16_t);

#endif /* GUESS_NR_H_ */